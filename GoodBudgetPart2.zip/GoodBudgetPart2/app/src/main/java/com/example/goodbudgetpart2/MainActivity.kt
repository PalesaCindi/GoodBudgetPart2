package com.example.goodbudgetpart2

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Toast
import android.content.Intent


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Link UI components
        val usernameInput = findViewById<EditText>(R.id.editTextText)
        val passwordInput = findViewById<EditText>(R.id.editTextTextPassword)
        val confirmPasswordInput = findViewById<EditText>(R.id.editTextTextPassword2)
        val emailInput = findViewById<EditText>(R.id.editTextEmali2)

        val submitButton = findViewById<Button>(R.id.buttonSubmit)
        val resetButton = findViewById<Button>(R.id.buttonRest)

        // Button listeners
        submitButton.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()
            val confirmPassword = confirmPasswordInput.text.toString()
            val email = emailInput.text.toString()

            if (password != confirmPassword) {
                Toast.makeText(this, "Passwords do not match!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Welcome $username!", Toast.LENGTH_SHORT).show()
                // You can proceed to another activity or save data here

                val intent = Intent(this, MainActivity_login::class.java)
                startActivity(intent)
                finish()
            }
        }

        resetButton.setOnClickListener {
            usernameInput.text.clear()
            passwordInput.text.clear()
            confirmPasswordInput.text.clear()
            emailInput.text.clear()
        }

    }
}
package com.example.goodbudgetpart2

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity_login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_login)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnSignUp = findViewById<Button>(R.id.btnSignUp)
        val btnRest = findViewById<Button>(R.id.buttonRest)

        btnLogin.setOnClickListener {
            // TODO: Handle login logic here
        }

        btnSignUp.setOnClickListener {
            // Launch signup page
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        btnRest.setOnClickListener {
            //  clear fields or reset form
        }
    }
}


